
import React from 'react';

const AboutPage: React.FC = () => {
  return (
    <div className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
              About Infosys InsurAI
            </h1>
            <p className="mt-6 text-xl text-gray-600">
              Revolutionizing the insurance industry with cutting-edge artificial intelligence and automation.
            </p>
          </div>

          <div className="mt-12 prose prose-lg prose-blue text-gray-600 mx-auto">
            <h2>Our Mission</h2>
            <p>
              Our mission at Infosys InsurAI is to empower insurance companies with intelligent tools that simplify complexity, mitigate risk, and drive growth. We believe that by automating the mundane and providing deep, actionable insights, we can free up industry professionals to focus on what matters most: serving their clients and building a more resilient future.
            </p>
            
            <h2>The InsurAI Platform</h2>
            <p>
              The InsurAI Corporate Policy Automation and Intelligence System is a comprehensive, cloud-native platform designed to handle the entire lifecycle of corporate insurance policies. From initial underwriting and risk assessment to ongoing management and compliance monitoring, InsurAI provides a single source of truth.
            </p>
            <ul>
              <li><strong>Intelligent Document Processing:</strong> Extract and analyze data from any policy document, no matter the format.</li>
              <li><strong>Predictive Risk Analysis:</strong> Utilize historical data and external factors to predict potential risks and suggest mitigation strategies.</li>
              <li><strong>Dynamic Compliance Engine:</strong> Our system continuously updates with the latest regulations to ensure your policies are always compliant.</li>
              <li><strong>Seamless Integration:</strong> InsurAI is built with an API-first approach, allowing for easy integration with your existing systems and workflows.</li>
            </ul>
            
            <h2>Powered by Infosys</h2>
            <p>
              As a part of Infosys, a global leader in next-generation digital services and consulting, InsurAI is backed by decades of technological expertise and a deep understanding of the financial services sector. We are committed to delivering excellence, innovation, and value to our clients around the world.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
