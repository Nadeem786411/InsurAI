
export type Page = 'home' | 'about' | 'contact' | 'login' | 'register';
